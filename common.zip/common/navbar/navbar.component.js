import template from './navbar.html';
import NavbarController from './navbar.controller';


let navbarComponent = {
  template,
  NavbarController
};

export default navbarComponent;
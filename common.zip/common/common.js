import angular from 'angular';
import Navbar from './navbar/navbar';
import Footer from './footer/footer';
import Header from './header/header';

let commonModule = angular.module('app.common', [
  Navbar,
  Footer,
  Header
])
  
.name;

export default commonModule;
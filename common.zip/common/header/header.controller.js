class HeaderController {
    constructor() {
      this.name = 'navbar';
    }
  }
  
  export default HeaderController;
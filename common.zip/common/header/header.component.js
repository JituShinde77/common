import template from './header.html';
import controller from './header.controller';


let headerComponent = {
  template,
  controller
};

export default headerComponent;
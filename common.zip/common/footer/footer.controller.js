class FooterController {
    constructor() {
      this.name = 'navbar';
    }
  }
  
  export default FooterController;
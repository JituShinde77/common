import template from './footer';
import FooterController from './footer.controller';


let footerComponent = {
  template,
  FooterController
};

export default footerComponent;